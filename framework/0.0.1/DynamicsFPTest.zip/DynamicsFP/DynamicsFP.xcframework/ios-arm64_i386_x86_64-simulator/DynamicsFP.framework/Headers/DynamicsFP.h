//
//  DynamicsFP.h
//  DynamicsFP
//
//  Copyright (c) 2020 Microsoft. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for DynamicsFP.
FOUNDATION_EXPORT double DynamicsFPVersionNumber;

//! Project version string for DynamicsFP.
FOUNDATION_EXPORT const unsigned char DynamicsFPVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DynamicsFP/PublicHeader.h>


